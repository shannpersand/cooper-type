"""
wifi:
    network: cooper
    passwordL coopercu
    Aruba login, sign in with:
    user: wifi_type1
    password: 7nkcvt
"""

# - simple drawing
# - python
#   - expressions, math
#   - variables
#   - loops
#   - conditionals
#   - functions
#   - lists !!! ********

# - canvas
# - colors
# - shapes
# - text
# - paths  =============
# - transformations
# - images
# - export pixel/pdf/svg
# - pages
# - frames/animation

# Varaible window thing

# vimeo link
