# this is a comment

print "hello!"  # make some textual output

# draw something
rect(326, 372, 359, 296)
