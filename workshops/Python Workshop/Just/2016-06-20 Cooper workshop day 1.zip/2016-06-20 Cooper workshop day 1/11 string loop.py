txt = "Hello Cooper Square"

# loop through all the letters in a string
for letter in txt:
    print letter
