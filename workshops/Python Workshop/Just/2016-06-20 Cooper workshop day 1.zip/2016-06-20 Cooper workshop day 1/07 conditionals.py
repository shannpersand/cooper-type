a = 7
# print a > 10

if a > 10:
    print "a is greater than 10"
elif a < 0:
    print "a is less than 0"
else:
    print "a is not greater than 10"


# there is ALWAYS one "if"
# there can be zero or more "elif"s
# thare can be at most ONE "else"
