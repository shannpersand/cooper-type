print "hello \"there\"!"

print 2 * 2.5

myNumber = 123
anotherNumber = 12
print myNumber * anotherNumber

print "done."

# keywords, or "reserved words" that you
# cannot use as variable names:
# ['and', 'as', 'assert', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'exec', 'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'not', 'or', 'pass', 'print', 'raise', 'return', 'try', 'while', 'with', 'yield']