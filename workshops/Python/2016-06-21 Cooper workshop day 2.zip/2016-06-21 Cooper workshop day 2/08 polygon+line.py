stroke(1, 0, 0)
strokeWidth(5)
polygon((56, 218), (150, 556), (562, 578), (606, 230), (300, 50))

fill(None)  # no fill
stroke(0)   # black stroke
strokeWidth(40)

line((200, 700), (814, 794))
