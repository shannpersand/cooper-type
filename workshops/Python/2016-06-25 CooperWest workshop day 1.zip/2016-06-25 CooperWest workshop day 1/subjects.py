Python
- print
- strings
- math
- variables
- loop
- conditionals
- functions
- objects/classes

RoboFont:
- Mechanic
- DrawBot, proofing

- CurrentFont()
- CurrentGlyph()
- font.info
- glyph.width etc
- getting points
- font.kerning
- drawing with pens
- moving/scaling/etc/copying
- interpolation
- boolean operations
- extensions, live drawing in the background
- checking composites, widths, ...
- SVG/PostScript pen? Maybe.

