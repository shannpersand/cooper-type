# open a UFO from a relative path
# (relative to the folder in which the script has been saved)

f = OpenFont("DemoFonts/SourceSansPro_0_subset.ufo")
