# this is my first Python program
print 'Hello Letterform Archive!'

print (123 + 12) * 100
print 1/2
print 2
# print 2.0; print "another thing"
print 1, 2, 123123/300, "hello"
a = 1234

print a * 12

abcXYZ_123 = "also a name"  # this is a comment
# You can't use 'reserved words' or 'keywords' as
# variable names:
    # and
    # as
    # assert
    # break
    # class
    # continue
    # def
    # del
    # elif
    # else
    # except
    # exec
    # finally
    # for
    # from
    # global
    # if
    # import
    # in
    # is
    # lambda
    # not
    # or
    # pass
    # print
    # raise
    # return
    # try
    # while
    # with
    # yield

# print A
# print a / 0

iffff = 12
