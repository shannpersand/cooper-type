def adder(a, b):
    # print number
    return a + b

result = adder(5, 3)
print result

# a and b are local to the adder function, so are not visible here:
# print a, b
