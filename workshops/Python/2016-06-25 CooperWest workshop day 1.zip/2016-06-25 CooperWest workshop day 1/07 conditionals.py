
a = 15

if a > 10:
    print "hey, yes, a is greater than 10!"
    print "(another line of code)"
else:
    print "no, a is not greater than 10."
    print "(another branch)"


if a > 10 and a < 20:
    print "a is between 10 and 20"

if 10 < a < 20:
    print "a is between 10 and 20"

