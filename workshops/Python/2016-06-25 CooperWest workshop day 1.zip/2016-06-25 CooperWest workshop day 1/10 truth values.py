# a = 5

# print True, False
# print 0, 1
# print a > 10

mylists = [1, 2, 5, "one hundred"]
myemptylist = []

# many things have the notion of being "true" or "false"
# in the context of an "if" statement.
if "":
    print "the thing was True"
else:
    print "the thing was False"

# things that can be seen as true:
    # - True
    # - numbers that are not zero
    # - lists that are not empty
    # - strings that are not empty
    # - ("collections" that are not empty)
    # - ... more
# things that can be seen as false:
    # - False
    # - the number zero
    # - an empty collection (such as a list or a string)
    # - None -> the "special" None object
