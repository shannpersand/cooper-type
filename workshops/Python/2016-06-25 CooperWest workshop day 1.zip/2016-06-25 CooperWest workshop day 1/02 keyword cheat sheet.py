import keyword

for kw in keyword.kwlist:
    print kw
